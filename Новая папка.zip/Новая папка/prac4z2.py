def main():
    filename = input("Введите имя файла: ")
    try:
        with open(filename, 'r') as file:
            lines = file.readlines()
        
        for index, line in enumerate(lines, start=1):
            print(f"{index} {line.rstrip()}")
    
    except FileNotFoundError:
        print(f"Ошибка: файл '{filename}' не найден.")
    except Exception as e:
        print(f"Ошибка: {e}")

if __name__ == "__main__":
    main()