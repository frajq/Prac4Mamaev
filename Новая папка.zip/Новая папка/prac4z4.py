def merge_files(input_files, output_file):
    with open(output_file, 'wb') as outfile:  
        for fname in input_files:
            with open(fname, 'rb') as infile: 
                outfile.write(infile.read())  

def main():
    input_files = input("Введите имена файлов для объединения, разделенные запятыми: ").split(',')
    input_files = [file.strip() for file in input_files]  
    output_file = input("Введите имя выходного файла: ")
    
    merge_files(input_files, output_file)
    print(f"Файлы {', '.join(input_files)} успешно объединены в {output_file}.")

if __name__ == "__main__":
    main()