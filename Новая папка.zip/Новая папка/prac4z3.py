def split_file(file_name, max_lines):
    try:
        with open(file_name, 'r') as file:
            lines = file.readlines()
        
        file_count = 1
        for i in range(0, len(lines), max_lines):
            part_lines = lines[i:i+max_lines]
            output_file_name = f"{file_count}.txt"
            with open(output_file_name, 'w') as output_file:
                output_file.writelines(part_lines)
            file_count += 1
        
        print(f"Файл разделен на {file_count - 1} частей.")
    except FileNotFoundError:
        print(f"Файл с именем {file_name} не найден.")
    except Exception as e:
        print(f"Произошла ошибка: {str(e)}")

if __name__ == "__main__":
    input_file = input("Введите имя входного файла: ")
    max_lines = int(input("Введите максимальное количество строк: "))
    split_file(input_file, max_lines)
    